package com.example.demo.handler;

import com.example.demo.service.DynamicGlueSchemaValidator;
import com.example.demo.service.DynamicGlueSchemaValidator.ValidationResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ValidationController {

    private final DynamicGlueSchemaValidator validator;

    public ValidationController() {
        // region and registry can be set via env vars in production
        this.validator = new DynamicGlueSchemaValidator(System.getenv().getOrDefault("AWS_REGION","us-east-1"),
                System.getenv().getOrDefault("GLUE_REGISTRY","test-registry"));
    }

    @PostMapping("/validate")
    public Map<String,Object> validate(@RequestBody Map<String,Object> payload) {
        ValidationResult res = validator.validate(payload);
        return Map.of("valid", res.isValid(), "matchedSchema", res.getMatchedSchema(), "error", res.getError(), "fieldErrors", res.getFieldErrors());
    }
}
