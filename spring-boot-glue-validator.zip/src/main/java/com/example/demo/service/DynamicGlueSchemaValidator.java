package com.example.demo.service;

import com.amazonaws.services.schemaregistry.client.AWSSchemaRegistryClient;
import com.amazonaws.services.schemaregistry.serializers.avro.AWSAvroSerializer;
import com.amazonaws.services.schemaregistry.utils.GlueSchemaRegistryConfiguration;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;
import java.util.stream.Collectors;

public class DynamicGlueSchemaValidator {

    private final AWSAvroSerializer serializer;
    private final AWSSchemaRegistryClient client;
    private final String registryName;
    private final ObjectMapper mapper = new ObjectMapper();

    public DynamicGlueSchemaValidator(String region, String registryName) {
        this.registryName = registryName;

        GlueSchemaRegistryConfiguration config = new GlueSchemaRegistryConfiguration(region);
        config.setRegistryName(registryName);

        this.client = new AWSSchemaRegistryClient(config);
        this.serializer = new AWSAvroSerializer(config);
    }

    public ValidationResult validate(Map<String, Object> input) {
        List<String> allErrors = new ArrayList<>();

        try {
            List<String> schemaNames = client.listSchemas(registryName)
                    .stream()
                    .map(s -> s.getSchemaName())
                    .collect(Collectors.toList());

            for (String schemaName : schemaNames) {
                try {
                    String schemaDef = client.getSchemaDefinition(schemaName);
                    Schema schema = new Schema.Parser().parse(schemaDef);
                    GenericRecord record = mapToGenericRecord(input, schema);
                    serializer.serialize(schemaName, record);
                    return ValidationResult.success(schemaName);
                } catch (Exception ex) {
                    String errMsg = ex.getMessage();
                    String fieldErr = extractFieldError(errMsg);
                    if (fieldErr != null) {
                        allErrors.add(schemaName + " -> " + fieldErr);
                    } else {
                        allErrors.add(schemaName + " -> " + errMsg);
                    }
                }
            }
            return ValidationResult.failureWithErrors("No schema matched", allErrors);
        } catch (Exception e) {
            return ValidationResult.failure("Validation failed: " + e.getMessage());
        }
    }

    private GenericRecord mapToGenericRecord(Map<String, Object> input, Schema schema) {
        GenericRecord record = new GenericData.Record(schema);
        for (Schema.Field field : schema.getFields()) {
            Object val = input.get(field.name());
            if (val != null) {
                record.put(field.name(), val);
            } else if (field.defaultVal() != null) {
                record.put(field.name(), field.defaultVal());
            }
        }
        return record;
    }

    private String extractFieldError(String raw) {
        if (raw == null) return null;
        if (raw.contains("not a valid Avro type")) {
            return "Invalid Avro field type - " + raw;
        }
        if (raw.contains("Field") && raw.contains("type")) {
            return raw;
        }
        if (raw.contains("Expected") && raw.contains("Got")) {
            return raw;
        }
        if (raw.contains("Cannot parse")) {
            return raw;
        }
        return null;
    }

    public static class ValidationResult {
        private final boolean valid;
        private final String matchedSchema;
        private final String error;
        private final List<String> fieldErrors;

        private ValidationResult(boolean valid, String matchedSchema, String error, List<String> fieldErrors) {
            this.valid = valid;
            this.matchedSchema = matchedSchema;
            this.error = error;
            this.fieldErrors = fieldErrors;
        }

        public static ValidationResult success(String schemaName) {
            return new ValidationResult(true, schemaName, null, Collections.emptyList());
        }

        public static ValidationResult failure(String msg) {
            return new ValidationResult(false, null, msg, Collections.emptyList());
        }

        public static ValidationResult failureWithErrors(String msg, List<String> errors) {
            return new ValidationResult(false, null, msg, errors);
        }

        public boolean isValid() { return valid; }
        public String getMatchedSchema() { return matchedSchema; }
        public String getError() { return error; }
        public List<String> getFieldErrors() { return fieldErrors; }
    }
}
