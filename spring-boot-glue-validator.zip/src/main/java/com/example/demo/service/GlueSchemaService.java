package com.example.demo.service;

import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.glue.GlueClient;
import software.amazon.awssdk.services.glue.model.GetSchemaVersionRequest;
import software.amazon.awssdk.services.glue.model.GetSchemaVersionResponse;
import org.apache.avro.Schema;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Simple helper that attempts to load schema from local resources/schemas/<name>.avsc first,
 * otherwise the DynamicGlueSchemaValidator will use AWSSchemaRegistryClient directly.
 */
public class GlueSchemaService {

    public Schema loadLocalSchema(String name) {
        try {
            String path = "src/main/resources/schemas/" + name + ".avsc";
            if (Files.exists(Paths.get(path))) {
                String def = Files.readString(Paths.get(path));
                return new Schema.Parser().parse(def);
            }
        } catch (IOException ignored) {}
        return null;
    }
}
