Spring Boot project (minimal) for dynamic AWS Glue schema validation.
- Java 21, Spring Boot 3.3.5
- Contains DynamicGlueSchemaValidator that uses AWSAvroSerializer
- Controller: POST /validate accepts JSON payload (Map) and returns validation result
- Place local schemas under src/main/resources/schemas/<name>.avsc to test locally (Glue client will be used in real deployments)
