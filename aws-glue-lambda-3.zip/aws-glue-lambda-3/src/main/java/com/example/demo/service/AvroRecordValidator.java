package com.example.demo.service;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.function.Consumer;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;

import com.example.demo.service.GlueSchemaService.CachedSchema;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AvroRecordValidator {

    private static final ObjectMapper mapper = new ObjectMapper();

    private final Map<String, Consumer<Object>> logicalTypeValidators = new HashMap<>();

    public AvroRecordValidator() {

        // UUID validation
        logicalTypeValidators.put("uuid", val -> {
            if (val == null)
                throw new IllegalArgumentException("value is null for uuid");
            java.util.UUID.fromString(val.toString());
        });

        // Date validation (ISO LocalDate)
        logicalTypeValidators.put("date", val -> {
            if (val == null)
                throw new IllegalArgumentException("value is null for date");
            LocalDate.parse(val.toString());
        });

        // Timestamp validation (RFC3339 or epoch millis)
        logicalTypeValidators.put("timestamp-millis", val -> validateTimestamp(val, "timestamp-millis"));
        logicalTypeValidators.put("timestamp-micros", val -> validateTimestamp(val, "timestamp-micros"));

        // Explicit RFC3339 logical type validator
        logicalTypeValidators.put("rfc-datetime", val -> {
            if (val == null)
                throw new IllegalArgumentException("value is null for rfc-datetime");
            try {
                OffsetDateTime.parse(val.toString(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
            } catch (DateTimeParseException e) {
                throw new IllegalArgumentException("Invalid RFC3339 datetime: " + val);
            }
        });
    }

    private void validateTimestamp(Object val, String logicalType) {
        if (val == null)
            throw new IllegalArgumentException("value is null for " + logicalType);

        String s = val.toString();

        // Try RFC3339 first
        try {
            OffsetDateTime.parse(s, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
            return;
        } catch (DateTimeParseException ignored) {
        }

        // Try epoch millis fallback
        try {
            long epoch = Long.parseLong(s);
            Instant.ofEpochMilli(epoch);
        } catch (Exception ex) {
            throw new IllegalArgumentException("Invalid timestamp value: must be RFC3339 or epoch millis");
        }
    }

    // ==============================
    // Core schema validation
    // ==============================
    public ValidationResult validateAgainstSchema(CachedSchema cachedSchema, Map<String, Object> inputMap) {
        String jsonInput;
        try {
            jsonInput = mapper.writeValueAsString(inputMap);
        } catch (Exception e) {
            return ValidationResult.failure("Failed to serialize input map: " + e.getMessage());
        }

        Schema avroSchema = cachedSchema.getAvroSchema();
        try {
            GenericDatumReader<GenericRecord> reader = new GenericDatumReader<>(avroSchema);
            Decoder decoder = DecoderFactory.get().jsonDecoder(avroSchema, jsonInput);
            GenericRecord record = reader.read(null, decoder);

            List<String> fieldErrors = runLogicalValidations(record, avroSchema);
            if (!fieldErrors.isEmpty()) {
                return ValidationResult.failureWithErrors(fieldErrors);
            }

            Map<String, Object> parsed = genericRecordToMap(record);
            return ValidationResult.success(parsed);

        } catch (IOException e) {
            return ValidationResult.structureMismatch(e.getMessage());
        } catch (Exception e) {
            return ValidationResult.failure(e.getMessage());
        }
    }

    // ==============================
    // Logical + custom validations
    // ==============================
    private List<String> runLogicalValidations(GenericRecord record, Schema avroSchema) {
        List<String> errors = new ArrayList<>();
        for (Schema.Field field : avroSchema.getFields()) {
            Object value = record.get(field.name());
            Schema fieldSchema = field.schema();
            Schema nonNull = getNonNullSchema(fieldSchema);

            String logicalType = nonNull.getProp("logicalType");
            if (logicalType != null) {
                Consumer<Object> validator = logicalTypeValidators.get(logicalType.toLowerCase());
                if (validator != null) {
                    try {
                        validator.accept(value);
                    } catch (Exception e) {
                        errors.add("Field[" + field.name() + "] logicalType[" + logicalType + "]: " + e.getMessage());
                    }
                }
            } else {
                // Fallback: auto-validate any field name that looks like a timestamp/date
                if (nonNull.getType() == Schema.Type.STRING && looksLikeTimestampField(field.name())) {
                    try {
                        if (value != null)
                            OffsetDateTime.parse(value.toString(), DateTimeFormatter.ISO_OFFSET_DATE_TIME);
                    } catch (Exception e) {
                        errors.add("Field[" + field.name() + "] RFC3339 validation failed: " + e.getMessage());
                    }
                }
            }

            // Handle custom validations (min, max, regex)
            String custom = nonNull.getProp("validation");
            if (custom != null && value != null) {
                try {
                    applyCustomValidation(custom, value);
                } catch (Exception e) {
                    errors.add("Field[" + field.name() + "] custom validation: " + e.getMessage());
                }
            }
        }
        return errors;
    }

    private void applyCustomValidation(String customValidation, Object value) {
        String[] parts = customValidation.split(",");
        for (String p : parts) {
            p = p.trim();
            if (p.startsWith("min:")) {
                long min = Long.parseLong(p.substring("min:".length()));
                long val = Long.parseLong(value.toString());
                if (val < min)
                    throw new IllegalArgumentException("value < min(" + min + ")");
            } else if (p.startsWith("max:")) {
                long max = Long.parseLong(p.substring("max:".length()));
                long val = Long.parseLong(value.toString());
                if (val > max)
                    throw new IllegalArgumentException("value > max(" + max + ")");
            } else if (p.startsWith("regex:")) {
                String pattern = p.substring("regex:".length());
                if (!value.toString().matches(pattern))
                    throw new IllegalArgumentException("value does not match regex");
            }
        }
    }

    private Schema getNonNullSchema(Schema s) {
        if (s.getType() == Schema.Type.UNION) {
            for (Schema c : s.getTypes()) {
                if (c.getType() != Schema.Type.NULL)
                    return c;
            }
        }
        return s;
    }

    private Map<String, Object> genericRecordToMap(GenericRecord record) {
        Map<String, Object> map = new LinkedHashMap<>();
        for (Schema.Field f : record.getSchema().getFields()) {
            Object v = record.get(f.name());
            map.put(f.name(), v);
        }
        return map;
    }

    private boolean looksLikeTimestampField(String fieldName) {
        String n = fieldName.toLowerCase();
        return n.endsWith("at") || n.contains("time") || n.contains("date") || n.contains("timestamp");
    }

    // ==============================
    // ValidationResult inner class
    // ==============================
    public static class ValidationResult {
        private final boolean success;
        private final boolean structureMismatch;
        private final Map<String, Object> parsedRecord;
        private final List<String> errors;

        private ValidationResult(boolean success, boolean structureMismatch,
                                 Map<String, Object> parsedRecord, List<String> errors) {
            this.success = success;
            this.structureMismatch = structureMismatch;
            this.parsedRecord = parsedRecord;
            this.errors = errors;
        }

        public static ValidationResult success(Map<String, Object> parsed) {
            return new ValidationResult(true, false, parsed, Collections.emptyList());
        }

        public static ValidationResult failure(String message) {
            return new ValidationResult(false, false, null, Collections.singletonList(message));
        }

        public static ValidationResult failureWithErrors(List<String> errors) {
            return new ValidationResult(false, false, null, errors);
        }

        public static ValidationResult structureMismatch(String message) {
            return new ValidationResult(false, true, null, Collections.singletonList(message));
        }

        public boolean isSuccess() { return success; }
        public boolean isStructureMismatch() { return structureMismatch; }
        public Map<String, Object> getParsedRecord() { return parsedRecord; }
        public List<String> getErrors() { return errors; }
    }
}
