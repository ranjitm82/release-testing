package com.example.demo.util;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.glue.GlueClient;

public class AwsGlueClientFactory {

	public static GlueClient createClient(String region) {
		
		AwsBasicCredentials awsCreds = AwsBasicCredentials.create("AKIA3NCDF2JMLWSHH4V6", "qtz4AmQGpl+MyKA3uFKmKpfAr3EocLmkg3K8155T");

	    return GlueClient.builder()
	    		.region(Region.of(region))
	            .credentialsProvider(StaticCredentialsProvider.create(awsCreds)).build();

	    
	}
}