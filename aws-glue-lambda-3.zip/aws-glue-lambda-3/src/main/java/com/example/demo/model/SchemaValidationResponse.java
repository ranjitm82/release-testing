package com.example.demo.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SchemaValidationResponse {
	private boolean valid;
	private String matchedSchemaName;
	private String matchedSchemaVersionId;
	private Map<String, Object> parsedRecord; // generic parsed map
	private List<String> fieldValidationErrors;
}