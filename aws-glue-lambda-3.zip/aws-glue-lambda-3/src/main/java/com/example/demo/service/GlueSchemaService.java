package com.example.demo.service;

import java.time.Instant;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.avro.Schema;

import com.example.demo.util.AwsGlueClientFactory;

import software.amazon.awssdk.services.glue.GlueClient;
import software.amazon.awssdk.services.glue.model.GetSchemaVersionRequest;
import software.amazon.awssdk.services.glue.model.GetSchemaVersionResponse;
import software.amazon.awssdk.services.glue.model.ListSchemasRequest;
import software.amazon.awssdk.services.glue.model.ListSchemasResponse;
import software.amazon.awssdk.services.glue.model.RegistryId;
import software.amazon.awssdk.services.glue.model.SchemaId;
import software.amazon.awssdk.services.glue.model.SchemaListItem;
import software.amazon.awssdk.services.glue.model.SchemaVersionNumber;

public class GlueSchemaService {

	private final GlueClient glueClient;
	private final String registryName;
	private final Map<String, CachedSchema> schemaCache = new ConcurrentHashMap<>();

	public GlueSchemaService(String registryName, String awsRegion) {
		this.registryName = registryName;
		this.glueClient = AwsGlueClientFactory.createClient(awsRegion);
		loadAllSchemas();
	}

	private void loadAllSchemas() {
		String nextToken = null;
		do {
			ListSchemasResponse listResp = glueClient.listSchemas(ListSchemasRequest.builder()
					.registryId(RegistryId.builder().registryName(registryName).build()).nextToken(nextToken).build());

			for (SchemaListItem item : listResp.schemas()) {
				try {
// Get latest schema version
					GetSchemaVersionResponse versionResp = glueClient.getSchemaVersion(GetSchemaVersionRequest.builder()
							.schemaId(
									SchemaId.builder().registryName(registryName).schemaName(item.schemaName()).build())
							.schemaVersionNumber(SchemaVersionNumber.builder().latestVersion(true).build()).build());

					String schemaDef = versionResp.schemaDefinition();
					Schema avro = new Schema.Parser().parse(schemaDef);

					CachedSchema cs = new CachedSchema(item.schemaName(), versionResp.schemaVersionId(), avro, Instant.now());
					schemaCache.put(item.schemaName(), cs);

				} catch (Exception e) {
// log & skip
					System.err.println("Failed to load schema: " + item.schemaName() + " -> " + e.getMessage());
				}
			}

			nextToken = listResp.nextToken();
		} while (nextToken != null);
	}

	public Collection<CachedSchema> getAllCachedSchemas() {
		return schemaCache.values();
	}

	public static class CachedSchema {
		private final String schemaName;
		private final String versionId;
		private final Schema avroSchema;
		private final Instant loadedAt;

		public CachedSchema(String schemaName, String versionId, Schema avroSchema, Instant loadedAt) {
			this.schemaName = schemaName;
			this.versionId = versionId;
			this.avroSchema = avroSchema;
			this.loadedAt = loadedAt;
		}

		public String getSchemaName() {
			return schemaName;
		}

		public String getVersionId() {
			return versionId;
		}

		public Schema getAvroSchema() {
			return avroSchema;
		}

		public Instant getLoadedAt() {
			return loadedAt;
		}
	}
}