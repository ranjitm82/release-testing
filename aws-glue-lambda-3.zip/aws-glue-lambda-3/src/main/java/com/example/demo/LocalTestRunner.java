package com.example.demo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.lambda.runtime.Context;
import com.example.demo.handler.GlueValidatorLambdaHandler;
import com.example.demo.model.SchemaValidationResponse;

/**
 * Simple standalone test runner to invoke the AWS Glue schema validator Lambda handler.
 * This simulates an AWS Lambda event locally for testing and debugging.
 */
public class LocalTestRunner {

    public static void main(String[] args) {

        // ample input payload (Map<String, Object>)
        // Add or modify fields to test different schemas dynamically
    	Map<String, Object> input = new HashMap<>();
    	input.put("profileId", "550e8400-e29b-41d4-a716-446655440000");
    	input.put("email", "test@example.com");
    	input.put("tags", List.of("premium", "loyal"));
    	input.put("createdAt", "2025-10-29T14:45:00Z");
    	input.put("lastUpdatedAt", "2025-10-29T14:50:00+05:30");
    	input.put("status", "ACTIVE");
    	input.put("phoneNumber", "9876543210");
    	
//    	Map<String, Object> input = new HashMap<>();
//    	input.put("schemaName", "test3");  // optional, if you use schemaName routing logic
//    	input.put("id", "550e8400-e29b-41d4-a716-446655440000");
//    	input.put("test", "Hello GPT");
//    	input.put("createdAt", "2025-10-29T15:00:00Z"); // RFC3339 datetime
    	
        // Create the handler
        GlueValidatorLambdaHandler handler = new GlueValidatorLambdaHandler();

        // Optional: mock or null context
        Context context = null;

        // Invoke the handler (simulate Lambda invoke)
        SchemaValidationResponse response = handler.handleRequest(input, context);

        // Print the validation result
        System.out.println("---------------------------------------------------");
        System.out.println("Validation Completed");
        System.out.println("---------------------------------------------------");
        System.out.println("Is Valid: " + response.isValid());
        System.out.println("Matched Schema: " + response.getMatchedSchemaName());

        if (response.getFieldValidationErrors() != null && !response.getFieldValidationErrors().isEmpty()) {
            System.out.println("Field Validation Errors:");
            
            response.getFieldValidationErrors().forEach(error -> {
            	System.out.println(error);
            });
            
           
        } else {
            System.out.println("No field-level errors");
        }

        System.out.println("---------------------------------------------------");
    }
}
