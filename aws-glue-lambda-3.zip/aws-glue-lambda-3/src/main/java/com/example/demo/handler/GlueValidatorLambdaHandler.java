package com.example.demo.handler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.example.demo.model.SchemaValidationResponse;
import com.example.demo.service.AvroRecordValidator;
import com.example.demo.service.GlueSchemaService;
import com.example.demo.service.GlueSchemaService.CachedSchema;

public class GlueValidatorLambdaHandler implements RequestHandler<Map<String, Object>, SchemaValidationResponse> {

    private final String registryName = System.getenv().getOrDefault("GLUE_REGISTRY", "default-registry");
    private final String awsRegion = System.getenv().getOrDefault("AWS_REGION", "us-east-1");

    private final GlueSchemaService glueSchemaService = new GlueSchemaService(registryName, awsRegion);
    private final AvroRecordValidator recordValidator = new AvroRecordValidator();

    @Override
    public SchemaValidationResponse handleRequest(Map<String, Object> input, Context context) {

        List<String> structureErrors = new ArrayList<>();

        for (CachedSchema cs : glueSchemaService.getAllCachedSchemas()) {
            AvroRecordValidator.ValidationResult vr = recordValidator.validateAgainstSchema(cs, input);

            if (vr.isSuccess()) {
                return SchemaValidationResponse.builder()
                        .valid(true)
                        .matchedSchemaName(cs.getSchemaName())
                        .matchedSchemaVersionId(cs.getVersionId())
                        .parsedRecord(vr.getParsedRecord())
                        .fieldValidationErrors(Collections.emptyList())
                        .build();
            }

            if (vr.isStructureMismatch()) {
                structureErrors.add("schema:" + cs.getSchemaName() + " -> " + String.join(";", vr.getErrors()));
            } else {
                // If validation failed due to logical errors, record them
                structureErrors.add("schema:" + cs.getSchemaName() + " -> " + String.join(";", vr.getErrors()));
            }
        }

        return SchemaValidationResponse.builder()
                .valid(false)
                .matchedSchemaName(null)
                .matchedSchemaVersionId(null)
                .parsedRecord(null)
                .fieldValidationErrors(structureErrors)
                .build();
    }
}
